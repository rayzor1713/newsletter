/**
 * Join a series of values into one string.
 */
module.exports = (...args) => args.slice(0, -1).join('');
