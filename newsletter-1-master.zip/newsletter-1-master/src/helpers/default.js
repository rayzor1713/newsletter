module.exports = (value, defaultValue) => value || defaultValue;
